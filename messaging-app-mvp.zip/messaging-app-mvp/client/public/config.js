// Adresse du serveur Relais. À modifier si le serveur tourne ailleurs
// qu'en local sur le port 4000 (ex. déploiement distant).
const RELAIS_SERVER_URL = "http://localhost:4000";
