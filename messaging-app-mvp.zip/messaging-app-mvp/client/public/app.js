(function () {
  "use strict";

  const API = RELAIS_SERVER_URL;

  /* ---------------- State ---------------- */
  let token = localStorage.getItem("relais_token") || null;
  let me = localStorage.getItem("relais_username") || null;
  let socket = null;
  let rooms = [];
  let users = [];
  let onlineUsernames = new Set();
  let currentScope = { type: "room", target: "Général" };
  let typingTimeout = null;

  /* ---------------- DOM refs ---------------- */
  const authScreen = document.getElementById("authScreen");
  const appShell = document.getElementById("appShell");
  const serverNote = document.getElementById("serverNote");

  const authTabs = document.querySelectorAll(".auth-tab");
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");
  const loginError = document.getElementById("loginError");
  const registerError = document.getElementById("registerError");

  const meUsername = document.getElementById("meUsername");
  const logoutBtn = document.getElementById("logoutBtn");
  const roomList = document.getElementById("roomList");
  const dmList = document.getElementById("dmList");
  const addRoomBtn = document.getElementById("addRoomBtn");

  const chatTitle = document.getElementById("chatTitle");
  const chatStatus = document.getElementById("chatStatus");
  const messagesEl = document.getElementById("messages");
  const typingIndicator = document.getElementById("typingIndicator");
  const composerForm = document.getElementById("composerForm");
  const composerInput = document.getElementById("composerInput");

  const roomModal = document.getElementById("roomModal");
  const roomForm = document.getElementById("roomForm");
  const roomNameInput = document.getElementById("roomNameInput");
  const roomError = document.getElementById("roomError");
  const cancelRoomBtn = document.getElementById("cancelRoomBtn");

  /* ---------------- Helpers ---------------- */
  function fmtTime(ts) {
    const d = new Date(ts);
    return d.getHours().toString().padStart(2, "0") + ":" + d.getMinutes().toString().padStart(2, "0");
  }

  async function api(path, options) {
    const opts = options || {};
    opts.headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
    if (token) opts.headers.Authorization = "Bearer " + token;
    const res = await fetch(API + path, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) throw new Error((data && data.error) || "Erreur serveur.");
    return data;
  }

  /* ---------------- Server reachability check ---------------- */
  fetch(API + "/api/rooms", { headers: token ? { Authorization: "Bearer " + token } : {} })
    .then(() => { serverNote.textContent = "Serveur connecté sur " + API; })
    .catch(() => {
      serverNote.textContent = "⚠ Impossible de joindre le serveur (" + API + "). Vérifiez qu'il est démarré.";
    });

  /* ---------------- Auth tabs ---------------- */
  authTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      authTabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      const isLogin = tab.dataset.tab === "login";
      loginForm.classList.toggle("hidden", !isLogin);
      registerForm.classList.toggle("hidden", isLogin);
    });
  });

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    loginError.textContent = "";
    const username = document.getElementById("loginUsername").value.trim();
    const password = document.getElementById("loginPassword").value;
    try {
      const data = await api("/api/login", { method: "POST", body: JSON.stringify({ username, password }) });
      completeAuth(data.token, data.username);
    } catch (err) {
      loginError.textContent = err.message;
    }
  });

  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    registerError.textContent = "";
    const username = document.getElementById("registerUsername").value.trim();
    const password = document.getElementById("registerPassword").value;
    try {
      const data = await api("/api/register", { method: "POST", body: JSON.stringify({ username, password }) });
      completeAuth(data.token, data.username);
    } catch (err) {
      registerError.textContent = err.message;
    }
  });

  function completeAuth(newToken, username) {
    token = newToken;
    me = username;
    localStorage.setItem("relais_token", token);
    localStorage.setItem("relais_username", me);
    boot();
  }

  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("relais_token");
    localStorage.removeItem("relais_username");
    if (socket) socket.disconnect();
    token = null; me = null;
    location.reload();
  });

  /* ---------------- Boot after auth ---------------- */
  async function boot() {
    authScreen.classList.add("hidden");
    appShell.classList.remove("hidden");
    meUsername.textContent = me;

    connectSocket();
    await Promise.all([loadRooms(), loadUsers()]);
    selectRoom(rooms[0] ? rooms[0].name : "Général");
  }

  function connectSocket() {
    socket = io(API, { auth: { token } });

    socket.on("connect_error", (err) => {
      chatStatus.textContent = "Connexion temps réel indisponible (" + err.message + ")";
    });

    socket.on("roomMessage", (msg) => {
      if (currentScope.type === "room" && currentScope.target === msg.room) {
        appendMessage(msg.from, msg.text, msg.ts);
      }
    });

    socket.on("privateMessage", (msg) => {
      const other = msg.from === me ? msg.to : msg.from;
      if (currentScope.type === "dm" && currentScope.target === other) {
        appendMessage(msg.from, msg.text, msg.ts);
      }
    });

    socket.on("presence", ({ username, online }) => {
      if (online) onlineUsernames.add(username); else onlineUsernames.delete(username);
      renderDmList();
    });

    socket.on("onlineUsers", (list) => {
      onlineUsernames = new Set(list);
      renderDmList();
    });

    socket.on("roomCreated", ({ name }) => {
      if (!rooms.find((r) => r.name === name)) {
        rooms.push({ name });
        renderRoomList();
      }
    });

    socket.on("typing", (payload) => {
      if (payload.scope === "room" && currentScope.type === "room" && payload.target === currentScope.target) {
        showTyping(payload.from);
      } else if (payload.scope === "private" && currentScope.type === "dm" && payload.from === currentScope.target) {
        showTyping(payload.from);
      }
    });
  }

  function showTyping(from) {
    typingIndicator.textContent = from + " est en train d'écrire…";
    clearTimeout(typingIndicator._t);
    typingIndicator._t = setTimeout(() => { typingIndicator.textContent = ""; }, 2500);
  }

  /* ---------------- Rooms & users ---------------- */
  async function loadRooms() {
    rooms = await api("/api/rooms");
    renderRoomList();
  }

  async function loadUsers() {
    users = await api("/api/users");
    renderDmList();
  }

  function renderRoomList() {
    roomList.innerHTML = "";
    rooms.forEach((r) => {
      const li = document.createElement("li");
      li.className = "channel-item" + (currentScope.type === "room" && currentScope.target === r.name ? " active" : "");
      li.innerHTML = '<span class="name">#' + r.name + "</span>";
      li.addEventListener("click", () => selectRoom(r.name));
      roomList.appendChild(li);
    });
  }

  function renderDmList() {
    dmList.innerHTML = "";
    users.forEach((u) => {
      const online = onlineUsernames.has(u.username);
      const li = document.createElement("li");
      li.className = "channel-item" + (currentScope.type === "dm" && currentScope.target === u.username ? " active" : "");
      li.innerHTML =
        '<span class="dot' + (online ? " online" : "") + '"></span>' +
        '<span class="name">' + u.username + "</span>";
      li.addEventListener("click", () => selectDm(u.username));
      dmList.appendChild(li);
    });
    if (!users.length) {
      const empty = document.createElement("li");
      empty.className = "channel-item";
      empty.style.cursor = "default";
      empty.innerHTML = '<span class="name">Aucun autre compte pour l\'instant</span>';
      dmList.appendChild(empty);
    }
  }

  /* ---------------- Selecting a conversation ---------------- */
  async function selectRoom(name) {
    currentScope = { type: "room", target: name };
    chatTitle.textContent = "#" + name;
    chatStatus.textContent = "salon public";
    socket.emit("joinRoom", name);
    renderRoomList();
    renderDmList();
    messagesEl.innerHTML = '<p class="msg-empty">Chargement…</p>';
    try {
      const history = await api("/api/rooms/" + encodeURIComponent(name) + "/messages");
      renderHistory(history.map((m) => ({ from: m.from, text: m.text, ts: m.ts })));
    } catch (e) {
      messagesEl.innerHTML = '<p class="msg-empty">Impossible de charger l\'historique.</p>';
    }
  }

  async function selectDm(username) {
    currentScope = { type: "dm", target: username };
    chatTitle.textContent = username;
    chatStatus.textContent = onlineUsernames.has(username) ? "en ligne" : "hors ligne";
    renderRoomList();
    renderDmList();
    messagesEl.innerHTML = '<p class="msg-empty">Chargement…</p>';
    try {
      const history = await api("/api/private/" + encodeURIComponent(username));
      renderHistory(history.map((m) => ({ from: m.from, text: m.text, ts: m.ts })));
    } catch (e) {
      messagesEl.innerHTML = '<p class="msg-empty">Impossible de charger l\'historique.</p>';
    }
  }

  function renderHistory(list) {
    messagesEl.innerHTML = "";
    if (!list.length) {
      messagesEl.innerHTML = '<p class="msg-empty">Aucun message pour l\'instant. Lancez la conversation.</p>';
      return;
    }
    list.forEach((m) => appendMessage(m.from, m.text, m.ts, false));
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function appendMessage(from, text, ts, scroll) {
    const empty = messagesEl.querySelector(".msg-empty");
    if (empty) empty.remove();

    const wrap = document.createElement("div");
    wrap.className = "msg" + (from === me ? " mine" : "");
    wrap.innerHTML =
      '<span class="msg-meta">' + (from === me ? "vous" : from) + " · " + fmtTime(ts) + "</span>" +
      '<span class="msg-bubble"></span>';
    wrap.querySelector(".msg-bubble").textContent = text;
    messagesEl.appendChild(wrap);
    if (scroll !== false) messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  /* ---------------- Composer ---------------- */
  composerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = composerInput.value.trim();
    if (!text) return;
    if (currentScope.type === "room") {
      socket.emit("roomMessage", { room: currentScope.target, text });
    } else {
      socket.emit("privateMessage", { to: currentScope.target, text });
    }
    composerInput.value = "";
  });

  composerInput.addEventListener("input", () => {
    clearTimeout(typingTimeout);
    if (currentScope.type === "room") {
      socket.emit("typing", { scope: "room", target: currentScope.target });
    } else {
      socket.emit("typing", { scope: "private", target: currentScope.target });
    }
    typingTimeout = setTimeout(() => {}, 800);
  });

  /* ---------------- Create room modal ---------------- */
  addRoomBtn.addEventListener("click", () => {
    roomError.textContent = "";
    roomNameInput.value = "";
    roomModal.classList.remove("hidden");
    roomNameInput.focus();
  });
  cancelRoomBtn.addEventListener("click", () => roomModal.classList.add("hidden"));
  roomModal.addEventListener("click", (e) => { if (e.target === roomModal) roomModal.classList.add("hidden"); });

  roomForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    roomError.textContent = "";
    const name = roomNameInput.value.trim();
    try {
      await api("/api/rooms", { method: "POST", body: JSON.stringify({ name }) });
      await loadRooms();
      roomModal.classList.add("hidden");
      selectRoom(name);
    } catch (err) {
      roomError.textContent = err.message;
    }
  });

  /* ---------------- Auto-login if a token is stored ---------------- */
  if (token && me) {
    api("/api/me")
      .then(() => boot())
      .catch(() => {
        localStorage.removeItem("relais_token");
        localStorage.removeItem("relais_username");
        token = null; me = null;
      });
  }
})();
