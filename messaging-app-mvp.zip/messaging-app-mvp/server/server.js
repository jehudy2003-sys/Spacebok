/**
 * Relais — serveur de messagerie (MVP)
 * - Authentification par compte (pseudo + mot de passe)
 * - Salons publics (rooms) et messages privés (1-à-1)
 * - Stockage en mémoire uniquement : tout est perdu au redémarrage du serveur.
 */

const crypto = require("crypto");
const http = require("http");

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { nanoid } = require("nanoid");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString("hex");
const JWT_EXPIRES_IN = "7d";
const DEFAULT_ROOMS = ["Général", "Aléatoire", "Technique"];

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

/* ----------------------------------------------------------------------- */
/* Stockage en mémoire                                                     */
/* ----------------------------------------------------------------------- */

const users = new Map(); // key: pseudo en minuscules -> { username, passwordHash }
const rooms = new Map(); // key: nom du salon -> { name, messages: [] }
const privateChats = new Map(); // key: "userA::userB" (trié) -> messages[]
const onlineSockets = new Map(); // pseudo -> socket.id

DEFAULT_ROOMS.forEach((name) => rooms.set(name, { name, messages: [] }));

function conversationKey(a, b) {
  return [a, b].sort((x, y) => x.localeCompare(y)).join("::");
}

function signToken(username) {
  return jwt.sign({ username }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Authentification requise." });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.username = payload.username;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Session invalide ou expirée." });
  }
}

/* ----------------------------------------------------------------------- */
/* REST : authentification                                                 */
/* ----------------------------------------------------------------------- */

app.post("/api/register", (req, res) => {
  const { username, password } = req.body || {};
  const clean = String(username || "").trim();

  if (clean.length < 3) {
    return res.status(400).json({ error: "Le pseudo doit contenir au moins 3 caractères." });
  }
  if (!password || password.length < 4) {
    return res.status(400).json({ error: "Le mot de passe doit contenir au moins 4 caractères." });
  }
  if (users.has(clean.toLowerCase())) {
    return res.status(409).json({ error: "Ce pseudo est déjà pris." });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  users.set(clean.toLowerCase(), { username: clean, passwordHash });

  const token = signToken(clean);
  res.status(201).json({ token, username: clean });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  const record = users.get(String(username || "").trim().toLowerCase());

  if (!record || !bcrypt.compareSync(password || "", record.passwordHash)) {
    return res.status(401).json({ error: "Pseudo ou mot de passe incorrect." });
  }

  const token = signToken(record.username);
  res.json({ token, username: record.username });
});

app.get("/api/me", authMiddleware, (req, res) => {
  res.json({ username: req.username });
});

/* ----------------------------------------------------------------------- */
/* REST : salons                                                           */
/* ----------------------------------------------------------------------- */

app.get("/api/rooms", authMiddleware, (_req, res) => {
  res.json(Array.from(rooms.values()).map((r) => ({ name: r.name })));
});

app.post("/api/rooms", authMiddleware, (req, res) => {
  const clean = String((req.body || {}).name || "").trim();
  if (!clean) return res.status(400).json({ error: "Nom de salon requis." });
  if (clean.length > 30) return res.status(400).json({ error: "Nom de salon trop long (30 caractères max)." });
  if (rooms.has(clean)) return res.status(409).json({ error: "Ce salon existe déjà." });

  rooms.set(clean, { name: clean, messages: [] });
  io.emit("roomCreated", { name: clean });
  res.status(201).json({ name: clean });
});

app.get("/api/rooms/:name/messages", authMiddleware, (req, res) => {
  const room = rooms.get(req.params.name);
  if (!room) return res.status(404).json({ error: "Salon introuvable." });
  res.json(room.messages);
});

/* ----------------------------------------------------------------------- */
/* REST : utilisateurs & messages privés                                   */
/* ----------------------------------------------------------------------- */

app.get("/api/users", authMiddleware, (req, res) => {
  const list = Array.from(users.values())
    .map((u) => u.username)
    .filter((name) => name !== req.username)
    .map((name) => ({ username: name, online: onlineSockets.has(name) }));
  res.json(list);
});

app.get("/api/private/:username", authMiddleware, (req, res) => {
  const key = conversationKey(req.username, req.params.username);
  res.json(privateChats.get(key) || []);
});

/* ----------------------------------------------------------------------- */
/* WebSocket (Socket.IO) : authentification puis événements temps réel     */
/* ----------------------------------------------------------------------- */

io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(new Error("Authentification requise."));
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    socket.username = payload.username;
    next();
  } catch (err) {
    next(new Error("Session invalide."));
  }
});

io.on("connection", (socket) => {
  const { username } = socket;
  onlineSockets.set(username, socket.id);
  socket.join(DEFAULT_ROOMS[0]);
  io.emit("presence", { username, online: true });

  socket.emit("onlineUsers", Array.from(onlineSockets.keys()));

  socket.on("joinRoom", (roomName) => {
    if (!rooms.has(roomName)) return;
    socket.join(roomName);
  });

  socket.on("roomMessage", ({ room, text }) => {
    if (!rooms.has(room) || !text || !String(text).trim()) return;
    const msg = {
      id: nanoid(8),
      room,
      from: username,
      text: String(text).trim().slice(0, 2000),
      ts: Date.now(),
    };
    const roomData = rooms.get(room);
    roomData.messages.push(msg);
    if (roomData.messages.length > 200) roomData.messages.shift();
    io.to(room).emit("roomMessage", msg);
  });

  socket.on("privateMessage", ({ to, text }) => {
    const target = String(to || "").trim();
    if (!users.has(target.toLowerCase()) || !text || !String(text).trim()) return;

    const key = conversationKey(username, target);
    const msg = {
      id: nanoid(8),
      from: username,
      to: target,
      text: String(text).trim().slice(0, 2000),
      ts: Date.now(),
    };
    if (!privateChats.has(key)) privateChats.set(key, []);
    const thread = privateChats.get(key);
    thread.push(msg);
    if (thread.length > 200) thread.shift();

    socket.emit("privateMessage", msg);
    const targetSocketId = onlineSockets.get(target);
    if (targetSocketId) io.to(targetSocketId).emit("privateMessage", msg);
  });

  socket.on("typing", ({ scope, target }) => {
    if (scope === "room" && rooms.has(target)) {
      socket.to(target).emit("typing", { scope, from: username, target });
    } else if (scope === "private") {
      const targetSocketId = onlineSockets.get(target);
      if (targetSocketId) io.to(targetSocketId).emit("typing", { scope, from: username });
    }
  });

  socket.on("disconnect", () => {
    onlineSockets.delete(username);
    io.emit("presence", { username, online: false });
  });
});

server.listen(PORT, () => {
  console.log(`✅ Serveur Relais lancé sur http://localhost:${PORT}`);
  console.log(`   Salons par défaut : ${DEFAULT_ROOMS.join(", ")}`);
});
