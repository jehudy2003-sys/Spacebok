# Relais — MVP de messagerie

Application de messagerie temps réel : salons publics **et** messages privés,
avec comptes protégés par mot de passe.

⚠️ **Stockage en mémoire** : comptes, salons et messages sont perdus à chaque
redémarrage du serveur. C'est volontaire pour ce MVP — voir la section
"Aller plus loin" pour brancher une vraie base de données.

## Structure

```
messaging-app-mvp/
├── server/           API REST + WebSocket (Express + Socket.IO)
│   ├── server.js
│   └── package.json
└── client/           Interface web (HTML/CSS/JS, aucun framework)
    ├── server.js     petit serveur statique
    ├── package.json
    └── public/
        ├── index.html
        ├── style.css
        ├── app.js
        └── config.js  ← adresse du serveur (à modifier si besoin)
```

## Démarrer le projet

Deux terminaux, dans cet ordre (le serveur doit démarrer en premier) :

```bash
# Terminal 1 - Serveur
cd messaging-app-mvp/server
npm install
npm start
# → http://localhost:4000

# Terminal 2 - Client
cd messaging-app-mvp/client
npm install
npm start
# → http://localhost:3000
```

Ouvrez ensuite **http://localhost:3000** dans votre navigateur. Pour tester
la messagerie entre deux comptes, ouvrez une deuxième fenêtre (ou un onglet
en navigation privée) et créez un second compte.

## Fonctionnalités

- **Comptes** : inscription et connexion par pseudo + mot de passe (hashé
  avec bcrypt), session via jeton JWT valable 7 jours.
- **Salons publics** : trois salons par défaut (Général, Aléatoire,
  Technique), possibilité d'en créer d'autres depuis l'interface.
- **Messages privés** : conversation 1-à-1 avec n'importe quel autre compte
  enregistré, avec indicateur en ligne / hors ligne.
- **Temps réel** : messages, présence et indicateur de saisie ("en train
  d'écrire…") transmis instantanément via WebSocket (Socket.IO).

## Configuration

- Port du serveur : variable d'environnement `PORT` (défaut `4000`).
- Port du client : variable d'environnement `PORT` (défaut `3000`).
- Adresse du serveur utilisée par le client : `client/public/config.js`
  (à modifier si le serveur ne tourne pas sur `localhost:4000`, par exemple
  après déploiement).

## Aller plus loin

Ce projet est un MVP volontairement simple. Pistes d'évolution naturelles :

- **Persistance** : remplacer les `Map()` en mémoire du serveur par une
  vraie base (PostgreSQL, MongoDB, SQLite…) pour ne plus perdre les données
  au redémarrage.
- **Fichiers/images** : ajouter l'envoi de pièces jointes.
- **Notifications** : notifications navigateur ou push mobile pour les
  nouveaux messages reçus hors de l'onglet actif.
- **Déploiement** : héberger `server/` (Render, Railway, Fly.io…) et
  `client/` (Vercel, Netlify…) séparément, puis mettre à jour
  `config.js` et la configuration CORS du serveur en conséquence.
